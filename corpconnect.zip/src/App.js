import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './components/Login/Login';
import Register from './components/Register/Register';
import Header from './components/Header/Header';
import Footer from './components/Footer/Footer';
import AdminDashboard from './components/Admin/AdminDashboard';
import HRDashboard from './components/HR/HrDashboard';


function App() {
  return (
    <>
      <Router>
        <Header /> 
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
         <Route path="/hr/dashboard" element={<HRDashboard />} />
        </Routes>
        <Footer /> 
      </Router>
    </>
  );
}

export default App;
