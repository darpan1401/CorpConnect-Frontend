const companies = ["TCS", "Infosys", "Wipro", "HCL"];

export default companies;
