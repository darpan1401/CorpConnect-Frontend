"use client";

import { useState } from "react";
import styles from "./HrDashboard.module.css";

const HRDashboard = () => {
  const [hrData] = useState({
    companyName: "TCS",
    hrName: "HR Manager",
  });

  const [upcomingEvents] = useState([
    {
      id: 1,
      title: "Wellness Camp 2024",
      description:
        "Annual health checkup and wellness activities for all employees. Includes health screenings, yoga sessions, and nutrition consultations.",
      date: "2024-02-15",
      venue: "Main Conference Hall",
      type: "wellness",
    },
    {
      id: 2,
      title: "Leadership Training Workshop",
      description:
        "Advanced leadership skills development program for senior employees and team leads. Interactive sessions with industry experts.",
      date: "2024-02-20",
      venue: "Training Center - Room 301",
      type: "training",
    },
  ]);

  const [pastEvents] = useState([
    {
      id: 3,
      title: "Team Dinner 2023",
      description:
        "Annual team dinner celebration with awards ceremony and entertainment. A night to celebrate our achievements and bond as a team.",
      date: "2023-12-15",
      venue: "Grand Ballroom, Hotel Meridian",
      type: "social",
    },
    {
      id: 4,
      title: "Annual Day Celebration",
      description:
        "Company's annual day celebration with cultural performances, awards, and recognition ceremony for outstanding employees.",
      date: "2023-11-25",
      venue: "Corporate Auditorium",
      type: "annual",
    },
  ]);

  const formatDate = (dateString) => {
    const options = {
      year: "numeric",
      month: "long",
      day: "numeric",
      weekday: "long",
    };
    return new Date(dateString).toLocaleDateString("en-US", options);
  };

  const downloadEventsPDF = () => {
    alert("PDF download functionality will be implemented with backend integration");
    console.log("Downloading events PDF for company:", hrData.companyName);
  };

  const EventCard = ({ event, isPast = false }) => (
    <div
      className={`${styles.eventCard} ${
        isPast ? styles.pastEvent : styles.upcomingEvent
      }`}
    >
      <div className={styles.eventHeader}>
        <h3 className={styles.eventTitle}>{event.title}</h3>
        <span className={`${styles.eventBadge} ${styles[event.type]}`}>
          {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
        </span>
      </div>
      <p className={styles.eventDescription}>{event.description}</p>
      <div className={styles.eventDetails}>
        <div className={styles.eventDate}>
          <span className={styles.dateIcon}>📅</span>
          <span>{formatDate(event.date)}</span>
        </div>
        <div className={styles.eventVenue}>
          <span className={styles.venueIcon}>📍</span>
          <span>{event.venue}</span>
        </div>
      </div>
    </div>
  );

  return (
    <div className={styles.dashboardContainer}>
      <nav className={styles.navHeader}>
        <div className={styles.navContent}>
          <div className={styles.navBrand}>
            <h1>CorpConnect</h1>
          </div>
          <div className={styles.navLinks}>
            <a href="#" className={styles.navLink}>
              Home
            </a>
            <a href="#" className={styles.navLink}>
              About Us
            </a>
            <a href="#" className={styles.navLink}>
              Contact Us
            </a>
            <a href="#" className={`${styles.navLink} ${styles.active}`}>
              HR Dashboard
            </a>
            <a href="#" className={styles.navLink}>
              Profile
            </a>
            <a href="#" className={`${styles.navLink} ${styles.logout}`}>
              Logout
            </a>
          </div>
          <div className={styles.mobileMenuBtn}>
            <span></span>
            <span></span>
            <span></span>
          </div>
        </div>
      </nav>

      <main className={styles.mainContent}>
        <div className={styles.welcomeSection}>
          <div className={styles.welcomeContent}>
            <div className={styles.welcomeText}>
              <h2 className={styles.welcomeMessage}>
                Welcome, HR of{" "}
                <span className={styles.companyHighlight}>{hrData.companyName}</span>
              </h2>
              <p className={styles.welcomeSubtitle}>
                Manage your company events and employee engagement activities
              </p>
            </div>
            <div className={styles.welcomeAnimation}>
              <div className={styles.animatedOffice}>
                <div className={styles.officeBuilding}>
                  <div className={styles.buildingFloor}>
                    <div className={styles.window}></div>
                    <div className={styles.window}></div>
                    <div className={styles.window}></div>
                  </div>
                  <div className={styles.buildingFloor}>
                    <div className={styles.window}></div>
                    <div className={styles.window}></div>
                    <div className={styles.window}></div>
                  </div>
                  <div className={styles.buildingFloor}>
                    <div className={styles.window}></div>
                    <div className={styles.window}></div>
                    <div className={styles.window}></div>
                  </div>
                </div>
                <div className={styles.floatingIcons}>
                  <div className={styles.icon}>👥</div>
                  <div className={styles.icon}>📊</div>
                  <div className={styles.icon}>🎯</div>
                  <div className={styles.icon}>💼</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className={styles.pdfDownloadSection}>
          <button onClick={downloadEventsPDF} className={styles.downloadBtn}>
            <span className={styles.downloadIcon}>📄</span>
            Download Events PDF
          </button>
        </div>

        <section className={styles.eventsSection}>
          <div className={styles.sectionHeader}>
            <h3 className={styles.sectionTitle}>Upcoming Events</h3>
            <span className={styles.eventCount}>{upcomingEvents.length} events</span>
          </div>
          <div className={styles.eventsGrid}>
            {upcomingEvents.length > 0 ? (
              upcomingEvents.map((event) => <EventCard key={event.id} event={event} />)
            ) : (
              <div className={styles.noEvents}>
                <p>No upcoming events scheduled</p>
              </div>
            )}
          </div>
        </section>

        <section className={styles.eventsSection}>
          <div className={styles.sectionHeader}>
            <h3 className={styles.sectionTitle}>Past Events</h3>
            <span className={styles.eventCount}>{pastEvents.length} events</span>
          </div>
          <div className={styles.eventsGrid}>
            {pastEvents.length > 0 ? (
              pastEvents.map((event) => (
                <EventCard key={event.id} event={event} isPast={true} />
              ))
            ) : (
              <div className={styles.noEvents}>
                <p>No past events to display</p>
              </div>
            )}
          </div>
        </section>
      </main>
    </div>
  );
};

export default HRDashboard;
