import React from "react";
import { Link, useNavigate } from "react-router-dom";
import styles from "./Header.module.css"; // create this file for styling

export default function Header() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));
  const role = user?.role || "";

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("");
  };

  return (
    <header className={styles.header}>
      <div className={styles.logo}>CorpConnect</div>
      <nav className={styles.nav}>
        <Link to="/home">Home</Link>
        <Link to="/about">About</Link>
        <Link to="/profile">Profile</Link>
        <Link to="/contact">Contact</Link>

        {role === "admin" && <Link to="/admin/dashboard">Admin Dashboard</Link>}
        {role === "hr" && <Link to="/hr/dashboard">HR Dashboard</Link>}

        <button className={styles.logoutBtn} onClick={handleLogout}>Logout</button>
      </nav>
    </header>
  );
}
